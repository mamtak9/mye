from django.contrib import admin
from .models import *

# Register your models here.



class PageAdmin(admin.ModelAdmin):
	list_display = ('id','day')

admin.site.register(day, PageAdmin)


class PageAdsmin(admin.ModelAdmin):
	list_display =('id', 'doctor', 'chamber', 'day', 'time_from', 'time_to')

admin.site.register(doctor_schedule, PageAdmin)


# class PageAdmin(admin.ModelAdmin):
# 	list_display = ('id','interval')

# admin.site.register(interval, PageAdmin)



class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'name')

admin.site.register(doctor_attendance, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'type')


admin.site.register(medicine_type, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'medicine_name','type')

admin.site.register(medicine, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'medicine_name','remark')

admin.site.register(remark, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'interval')

admin.site.register(interval, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id','medicine_name', 'interval')

admin.site.register(frequency_med, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display =('id', 'expertise')

admin.site.register(expertise, PageAdmin)

class PageAdmin(admin.ModelAdmin):
	list_display = ('id','name','expertise')

admin.site.register(doctor, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display = ('id','report_name',)


admin.site.register(report,PageAdmin)