from django.db import models
from django.utils import timezone

# Create your models here.
class expertise(models.Model):
	expertise = models.CharField(max_length=50)
	def __str__(self):
		return(str(self.expertise))

class doctor(models.Model):
	name = models.CharField(max_length=50)
	expertise = models.ForeignKey(expertise,on_delete=models.CASCADE)
	def __str__(self):
		return(str(self.name))

class day(models.Model):
	day = models.CharField(max_length=9)
	def __str__(self):
		return(str(self.day))

class chamber(models.Model):
	chamber = models.CharField(max_length = 50)
	def __str__(self):
		return(str(self.chamber))


class doctor_schedule(models.Model):
	doctor = models.ForeignKey(doctor,on_delete=models.CASCADE)
	chamber = models.ForeignKey(chamber,on_delete = models.CASCADE)
	day = models.ForeignKey(day,on_delete=models.CASCADE)
	time_from = models.TimeField(default=timezone.now)
	time_to = models.TimeField(default=timezone.now)


class doctor_attendance(models.Model):
	name = models.ForeignKey(doctor, on_delete=models.CASCADE)


class medicine_type(models.Model):
	type = models.CharField(max_length=20)
	def __str__(self):
		return(str(self.type))


class medicine(models.Model):
	medicine_name = models.CharField(max_length=50)
	type = models.ForeignKey(medicine_type, on_delete=models.CASCADE)
	def __str__(self):
		return(str(self.medicine_name + ' ' + str(self.type)))


class remark(models.Model):
	medicine_name = models.ForeignKey(medicine,on_delete = models.CASCADE)
	remark = models.CharField(max_length=50)
	def __str__(self):
		return(str(self.remark))



class interval(models.Model):
	interval = models.CharField(max_length = 20)
	def __str__(self):
		return(str(self.interval))	


class frequency_med(models.Model):
	medicine_name = models.ForeignKey(medicine,on_delete = models.CASCADE)
	interval = models.ForeignKey(interval ,on_delete = models.CASCADE, default = 'IT')

class report(models.Model):
	report_name = models.CharField(max_length=50)
	def __str__(self):
		return(str(self.report_name))
