from django.shortcuts import render, redirect
from django.http import HttpResponse

# Create your views here.


def home(request):
	if request.user.groups.filter(name__in=['pharmacist']).exists():
		return redirect('/medicine')
	elif request.user.groups.filter(name__in=['lab_technician']).exists():
		return redirect('/report')
	elif request.user.groups.filter(name__in=['receptionist']).exists():
		return redirect('registration/')

	return render(request, 'main/home.html')
