from django import forms
from .models import *


class patient_registration_form(forms.ModelForm):
	
	class Meta:
		model = register
		fields = ('registration_number','name','mobile_number','address','doctor_assigned','next_appointment')
