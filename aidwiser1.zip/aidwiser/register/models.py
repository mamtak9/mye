from django.db import models
from django.utils import timezone
from main.models import doctor
from django.contrib.auth.models import User

# Create your models here.


class register(models.Model):
	registration_number= models.CharField(max_length=9)
	name = models.CharField(max_length= 50)
	date = models.DateTimeField(default=timezone.now)
	mobile_number = models.IntegerField(max_length=10)
	address = models.TextField()
	doctor_assigned = models.ForeignKey(doctor,on_delete=models.CASCADE)
	next_appointment = models.DateField(null = True, default= timezone.now)
	Registration_date = models.DateTimeField(default=timezone.now, editable = False)
	submitter = models.ForeignKey(User, null = True, editable = False, on_delete = models.CASCADE)

	def __str__(self):
	    return str(self.registration_number)