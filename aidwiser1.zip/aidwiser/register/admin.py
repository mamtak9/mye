from django.contrib import admin
from .models import register
# Register your models here.


class PageAdmin(admin.ModelAdmin):
	list_display = ('registration_number','name', 'mobile_number', 'doctor_assigned', 'address', 'doctor_assigned', 'next_appointment')

admin.site.register(register, PageAdmin)
