from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.auth import views as views1

urlpatterns = [
	path('register/', views.register, name='registration'),
]