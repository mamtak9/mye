from django.shortcuts import render
from .forms import *


def register(request):
	if request.method == 'POST':
		form = patient_registration_form(request.POST)
		if form.is_valid():
			form.save()
	form = patient_registration_form()
	return render(request,'register/registration.html', {'form': form})
