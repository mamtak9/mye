from django.db import models
from django.contrib.auth.models import User
from main.models import medicine,interval,remark
from register.models import register
from main.models import report
from django.utils import timezone

# Create your models here.

class notification_medicine(models.Model):
	registration_number = models.ForeignKey(register,null=True, on_delete = models.CASCADE)
	medicine_name = models.ForeignKey(medicine, on_delete = models.CASCADE)
	total_dosage_left = models.IntegerField()
	dose = models.CharField(max_length=10)
	frequency = models.IntegerField(editable=True, default = 3)
	interval = models.ForeignKey(interval, on_delete = models.CASCADE, default = 0)
	remarks = models.ForeignKey(remark, on_delete = models.CASCADE)
	submission_date = models.DateTimeField(default=timezone.now, editable = False)
	submitter = models.ForeignKey(User, null = True, editable = False, on_delete = models.CASCADE)

	class Meta:
		unique_together = ('registration_number', 'medicine_name')

class notification_report(models.Model):
	registration_number = models.ForeignKey(register, on_delete = models.CASCADE)
	report = models.ForeignKey(report, on_delete = models.CASCADE)
	report_number = models.CharField(max_length = 20, unique = True)
	is_ready = models.BooleanField(default = 1)
	date = models.DateTimeField(default=timezone.now, editable = False)
	submitter = models.ForeignKey(User, null = True, editable = False, on_delete = models.CASCADE)
	class Meta:
		unique_together = ('registration_number', 'report_number')
