from django.contrib import admin
from django.urls import path, include
from . import views
from django.contrib.auth import views as views1

urlpatterns = [
	path('medicine/', views.medicine_new, name='medicine_new'),
	path('report/', views.report, name='report'),
    path('<int:registration_number>/medicine/', views.medicine, name='docs'),

]

