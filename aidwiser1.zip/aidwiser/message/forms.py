from django import forms
from .models import *
from main.models import *
from register.models import register

class notification_medicine_form(forms.Form):
	registration_number = forms.ModelChoiceField(queryset=register.objects.all())
	medicine_name = forms.ModelChoiceField(queryset = medicine.objects.all())
	total_dosage_left = forms.NumberInput()
	dose = forms.IntegerField()
	frequency = forms.IntegerField()
	interval = forms.ModelChoiceField( queryset = interval.objects.all())
	remarks = forms.ModelChoiceField(queryset = remark.objects.all())
	# class Meta:
		# model = notification_medicine
		# fields = ('registration_number', 'medicine_name','total_dosage_left','dose','frequency','interval','remarks')

class notification_report_form(forms.ModelForm):

	class Meta:
		model = notification_report
		fields = ('registration_number','report','report_number','is_ready')


class medicine_new_form(forms.Form):
	registration_number = forms.ModelChoiceField(queryset=register.objects.all())
