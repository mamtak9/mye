from django.shortcuts import render, HttpResponse, redirect
from .forms import *
from django.contrib.auth.models import Group
from .notification import sendSMS
from register.models import register




def medicine_new(request):
	if request.method == 'POST':
		form = medicine_new_form(request.POST)
		if form.is_valid():
			
			return medicine(request, form.cleaned_data['registration_number'])

	form = medicine_new_form()
	return render(request,'message/medicine.html',{'form' : form})

def medicine(request, registration_number):
	patient = register.objects.get(registration_number=registration_number)
	if request.user.groups.filter(name__in=['pharmacist']).exists():
		if request.method == 'POST':
			form = notification_medicine_form(request.POST)			
			if form.is_valid():
				form.cleaned_data['registration_number']=registration_number
				print(form.cleaned_data['registration_number'], form.cleaned_data['medicine_name'])
			return render(request,'message/medicine.html', {'form': form , 'patient' : patient})
		else:
			form = notification_medicine_form()
			return render(request,'message/medicine.html', {'form': form , 'patient' : patient})
		return render(request,'message/medicine.html', {'form': form , 'patient' : patient})
		
	else:
		return redirect('/')

def report(request):
	if request.user.groups.filter(name__in=['lab_Technician']).exists():

		if request.method == 'POST':
			form = notification_report_form(request.POST)
			if form.is_valid() and form.instance.is_ready:
				form.save()
				a = register.objects.get(regitration_number = form.instance.registration_number)
				message = 'Hey ' + a.name + ' your ' + str(form.instance.report) + 'report with id ' + form.instance.report_number + ' is ready. please collect it from office ASAP.'
				number = a.mobile_number
				# sendSMS('XEXBFOxST2Q-093vDWETmUSkLkvNYeUOOnMuvbrVYZ', number,'TXTLCL', message)
		form = notification_report_form()
		return render(request,'message/report.html', {'form': form})
	return redirect('/')
