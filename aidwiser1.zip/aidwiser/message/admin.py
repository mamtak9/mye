from django.contrib import admin
from .models import *
# Register your models here


class PageAdmin(admin.ModelAdmin):
	list_display = ('registration_number','medicine_name', 'total_dosage_left', 'frequency', 'remarks')


admin.site.register(notification_medicine, PageAdmin)


class PageAdmin(admin.ModelAdmin):
	list_display = ('registration_number','report','report_number', 'is_ready', 'date', 'submitter')


admin.site.register(notification_report,PageAdmin)